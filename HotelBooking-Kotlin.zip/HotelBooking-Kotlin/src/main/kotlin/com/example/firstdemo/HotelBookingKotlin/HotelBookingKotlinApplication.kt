package com.example.firstdemo.HotelBookingKotlin

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class HotelBookingKotlinApplication

fun main(args: Array<String>) {
	runApplication<HotelBookingKotlinApplication>(*args)
}
