rootProject.name = "HotelBooking-Kotlin"
